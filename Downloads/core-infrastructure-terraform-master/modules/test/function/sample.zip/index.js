exports.handle = function(event, context) {
 console.log(‘Hello, Cloudwatch!’);
 context.succeed(“Hello, World!”);
};
